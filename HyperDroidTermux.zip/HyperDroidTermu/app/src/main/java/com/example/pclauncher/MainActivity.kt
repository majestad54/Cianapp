package com.example.pclauncher

import android.os.Bundle
import android.view.MotionEvent
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {

    private lateinit var cursor: ImageView
    private lateinit var desktopLayout: ConstraintLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cursor = findViewById(R.id.cursor)
        desktopLayout = findViewById(R.id.desktopLayout)

        desktopLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    cursor.translationX = event.x - cursor.width / 2
                    cursor.translationY = event.y - cursor.height / 2
                }
            }
            true
        }
    }
}
