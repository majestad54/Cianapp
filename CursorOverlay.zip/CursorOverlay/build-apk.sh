#!/bin/bash

echo "================================================"
echo "  HyperDroid Cursor - Script de Compilación"
echo "================================================"
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -f "settings.gradle" ]; then
    echo "❌ Error: Este script debe ejecutarse desde la raíz del proyecto"
    exit 1
fi

# Hacer ejecutable el gradlew
chmod +x gradlew

echo "🔨 Compilando APK..."
echo ""

# Compilar
./gradlew assembleDebug

# Verificar si la compilación fue exitosa
if [ $? -eq 0 ]; then
    echo ""
    echo "================================================"
    echo "✅ ¡Compilación exitosa!"
    echo "================================================"
    echo ""
    echo "📦 Tu APK está listo en:"
    echo "   app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "📲 Próximos pasos:"
    echo "   1. Transfiere el APK a tu Android"
    echo "   2. Instálalo"
    echo "   3. Otorga los permisos necesarios"
    echo "   4. ¡Disfruta de los cursores en HyperDroid!"
    echo ""
else
    echo ""
    echo "❌ Error durante la compilación"
    echo "Revisa los mensajes de error arriba"
    exit 1
fi
