# 🖱️ Cursor Overlay para HyperDroid

Una aplicación Android que añade cursores personalizados tipo Windows sobre cualquier aplicación, especialmente diseñada para HyperDroid PC Launcher.

## ✨ Características

- ✅ **5 tipos de cursores**:
  - ↖️ Flecha Normal (cursor estándar)
  - 👆 Mano (para enlaces y botones)
  - ⏳ Cargando (con animación giratoria)
  - ➕ Cruz de Precisión (para diseño y edición)
  - ↔️ Redimensionar (flechas horizontales)

- ✅ **Personalización completa**:
  - Cambio de tamaño del cursor (20-100 dp)
  - Overlay transparente que funciona sobre todas las apps
  - Servicio persistente en segundo plano

- ✅ **Fácil de usar**:
  - Interfaz moderna estilo Windows 11
  - Controles simples e intuitivos
  - Se activa/desactiva con un solo toque

## 📱 Requisitos

- Android 6.0 (Marshmallow) o superior
- Permiso de "Mostrar sobre otras apps"

## 🚀 Cómo compilar el APK

### Opción 1: Con Android Studio (recomendado)

1. Descarga e instala [Android Studio](https://developer.android.com/studio)
2. Abre el proyecto en Android Studio
3. Espera a que sincronice las dependencias de Gradle
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. El APK se generará en `app/build/outputs/apk/debug/app-debug.apk`

### Opción 2: Desde línea de comandos

```bash
# En el directorio del proyecto
./gradlew assembleDebug

# El APK estará en:
# app/build/outputs/apk/debug/app-debug.apk
```

## 📲 Instalación

1. Transfiere el APK a tu dispositivo Android
2. Habilita "Instalar apps de fuentes desconocidas" en Configuración
3. Abre el APK y toca "Instalar"
4. Una vez instalado, abre la app "Cursor para HyperDroid"

## 🎮 Modo de uso

1. **Otorgar permisos**: 
   - Al abrir la app, toca "Otorgar Permisos"
   - Activa "Permitir mostrar sobre otras apps"

2. **Activar el cursor**:
   - Vuelve a la app
   - Activa el interruptor "Cursor Activo"
   - ¡Listo! Ya verás el cursor

3. **Personalizar**:
   - Selecciona el tipo de cursor que prefieras
   - Ajusta el tamaño con el control deslizante
   - Los cambios se aplican instantáneamente

4. **Usar con HyperDroid**:
   - Abre HyperDroid PC Launcher
   - El cursor aparecerá sobre la interfaz
   - Toca la pantalla para ver el cursor seguir tu dedo

## 🛠️ Cómo funciona

La app crea un **overlay transparente** que se muestra sobre todas las aplicaciones. Utiliza:

- `WindowManager` para crear la capa de overlay
- Servicio en primer plano para mantener el cursor activo
- Interceptor de eventos táctiles para seguir tu dedo
- Drawables vectoriales XML para cursores escalables

## ⚙️ Estructura del proyecto

```
CursorOverlay/
├── app/
│   ├── src/main/
│   │   ├── java/com/cursoroverlay/hyperdroid/
│   │   │   ├── MainActivity.java
│   │   │   └── CursorOverlayService.java
│   │   ├── res/
│   │   │   ├── drawable/
│   │   │   │   ├── cursor_arrow.xml
│   │   │   │   ├── cursor_hand.xml
│   │   │   │   ├── cursor_loading.xml
│   │   │   │   ├── cursor_crosshair.xml
│   │   │   │   └── cursor_resize.xml
│   │   │   └── layout/
│   │   │       └── activity_main.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
└── build.gradle
```

## 🎨 Personalización avanzada

Puedes editar los cursores en `app/src/main/res/drawable/` para crear tus propios diseños. Son archivos XML vectoriales.

## 🐛 Solución de problemas

**El cursor no aparece:**
- Verifica que otorgaste el permiso de overlay
- Asegúrate de activar el interruptor en la app
- Reinicia el servicio

**El cursor está muy pequeño/grande:**
- Ajusta el tamaño con el control deslizante

**La app se cierra:**
- Desactiva optimizaciones de batería para esta app

## 📄 Licencia

Código abierto para uso personal y educativo.

---

**¡Disfruta de tu cursor personalizado en HyperDroid! 🎉**
