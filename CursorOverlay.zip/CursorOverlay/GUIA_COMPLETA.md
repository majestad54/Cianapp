# 📱 GUÍA COMPLETA: Cursor para HyperDroid

## 🎯 ¿Qué es esta app?

Esta aplicación añade **cursores personalizados** (como los de Windows) que aparecen cuando tocas la pantalla en HyperDroid PC Launcher o cualquier otra app de Android.

---

## 📦 PASO 1: COMPILAR EL APK

### Método Recomendado: Android Studio

#### 1.1 Descargar Android Studio
- Ve a: https://developer.android.com/studio
- Descarga e instala Android Studio (es gratis)
- Requiere aproximadamente 3GB de espacio

#### 1.2 Abrir el proyecto
1. Abre Android Studio
2. Selecciona "Open" (Abrir)
3. Navega a la carpeta `CursorOverlay`
4. Haz clic en "OK"

#### 1.3 Esperar sincronización
- Android Studio descargará automáticamente las dependencias
- Esto puede tardar 5-10 minutos la primera vez
- Verás un mensaje "Gradle build finished" cuando termine

#### 1.4 Compilar el APK
1. En el menú superior: **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Espera a que compile (1-2 minutos)
3. Verás una notificación: "APK(s) generated successfully"
4. Haz clic en "locate" para ver el APK

#### 1.5 Encontrar tu APK
El archivo estará en:
```
CursorOverlay/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 PASO 2: INSTALAR EN TU ANDROID

### 2.1 Transferir el APK
Puedes usar cualquiera de estos métodos:

**Opción A - Cable USB:**
1. Conecta tu teléfono a la PC con cable USB
2. Copia `app-debug.apk` a la carpeta Descargas de tu teléfono

**Opción B - Google Drive:**
1. Sube `app-debug.apk` a Google Drive
2. Descárgalo desde tu teléfono

**Opción C - Correo:**
1. Envíate el APK por correo
2. Ábrelo desde tu teléfono

### 2.2 Habilitar instalación de apps desconocidas
1. Abre **Configuración** en tu Android
2. Ve a **Seguridad** o **Privacidad**
3. Busca "Instalar apps desconocidas" o "Fuentes desconocidas"
4. Habilita el permiso para tu navegador o administrador de archivos

### 2.3 Instalar el APK
1. Abre el archivo `app-debug.apk` en tu teléfono
2. Toca **Instalar**
3. Espera a que termine
4. Toca **Abrir** o busca el ícono de la app en tu pantalla

---

## 🎮 PASO 3: CONFIGURAR LA APP

### 3.1 Primera vez que abres la app
Verás una pantalla con:
- 🖱️ Título: "Cursor para HyperDroid"
- Un botón: "🔓 Otorgar Permisos" (activado)
- Un interruptor: "Cursor Activo" (desactivado)

### 3.2 Otorgar permiso de superposición
1. Toca el botón **"🔓 Otorgar Permisos"**
2. Se abrirá la configuración de Android
3. Busca "Cursor para HyperDroid" en la lista
4. Activa el permiso **"Permitir mostrar sobre otras apps"**
5. Vuelve a la app (botón atrás)

### 3.3 Activar el cursor
1. Ahora el interruptor "Cursor Activo" estará disponible
2. **Actívalo** (desliza a la derecha)
3. Verás un mensaje: "Cursor activado ✓"
4. También aparecerá una notificación persistente

---

## 🎨 PASO 4: PERSONALIZAR TU CURSOR

### 4.1 Elegir tipo de cursor

En la app verás 5 opciones:

- **↖️ Flecha Normal**: El cursor clásico de Windows
- **👆 Mano**: Para indicar que puedes hacer clic (como en enlaces)
- **⏳ Cargando**: Un círculo que gira (indica espera)
- **➕ Cruz de Precisión**: Para diseño o edición precisa
- **↔️ Redimensionar**: Flechas que indican cambio de tamaño

**Selecciona el que prefieras** tocando el círculo correspondiente.

### 4.2 Ajustar tamaño
1. Usa el control deslizante "Tamaño del Cursor"
2. Muévelo hacia la izquierda = cursor más pequeño
3. Muévelo hacia la derecha = cursor más grande
4. El número en azul muestra el tamaño actual

---

## 🚀 PASO 5: USAR CON HYPERDROID

### 5.1 Abrir HyperDroid
1. Minimiza o sal de la app "Cursor para HyperDroid"
2. Abre **HyperDroid PC Launcher**
3. ¡Ya verás tu cursor personalizado!

### 5.2 Cómo funciona
- Cuando **toques la pantalla**, aparecerá el cursor
- El cursor **sigue tu dedo** por toda la pantalla
- Funciona sobre **cualquier app**, no solo HyperDroid

### 5.3 Cambiar el cursor mientras usas HyperDroid
1. Desliza desde la parte superior de la pantalla
2. Toca la notificación "Cursor Personalizado"
3. Se abrirá la app de configuración
4. Cambia el tipo o tamaño del cursor
5. Vuelve a HyperDroid

---

## ⚙️ OPCIONES AVANZADAS

### Desactivar temporalmente el cursor
1. Abre la app "Cursor para HyperDroid"
2. Desactiva el interruptor "Cursor Activo"
3. El cursor desaparecerá

### Desactivar optimización de batería (Recomendado)
Para que el cursor no se cierre:
1. Ve a **Configuración** → **Batería**
2. Busca "Optimización de batería"
3. Encuentra "Cursor para HyperDroid"
4. Selecciona **"No optimizar"**

### Desinstalar la app
1. Mantén presionado el ícono de la app
2. Toca "Desinstalar" o arrastra a la papelera
3. Confirma

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### ❌ El cursor no aparece
**Solución:**
1. Verifica que otorgaste el permiso de "Mostrar sobre otras apps"
2. Asegúrate de activar el interruptor "Cursor Activo"
3. Reinicia la app: desactiva y vuelve a activar el cursor

### ❌ El APK no instala
**Solución:**
1. Verifica que habilitaste "Instalar apps de fuentes desconocidas"
2. Si tu Android es muy antiguo (menor a 6.0), la app no es compatible
3. Prueba descargando de nuevo el APK, puede estar corrupto

### ❌ La app se cierra sola
**Solución:**
1. Desactiva la optimización de batería (ver arriba)
2. En algunas marcas (Xiaomi, Huawei): ve a Configuración → Apps → Cursor para HyperDroid → **Permisos** → Habilita "Inicio automático"

### ❌ El cursor es muy pequeño o muy grande
**Solución:**
- Ajusta el tamaño con el control deslizante en la app
- Prueba valores entre 30-60 dp para un tamaño cómodo

### ❌ El cursor no sigue bien mi dedo
**Solución:**
- Esto puede pasar en dispositivos muy antiguos o con mucha RAM ocupada
- Cierra otras apps en segundo plano
- Reinicia tu teléfono

---

## 📊 ESPECIFICACIONES TÉCNICAS

- **Tamaño de la app**: ~2-3 MB
- **Android mínimo**: 6.0 (Marshmallow)
- **Permisos necesarios**: Mostrar sobre otras apps
- **Uso de batería**: Mínimo (servicio liviano)
- **Uso de RAM**: ~10-20 MB

---

## ❓ PREGUNTAS FRECUENTES

**P: ¿Funciona con otras apps además de HyperDroid?**
R: ¡Sí! Funciona con cualquier aplicación de Android.

**P: ¿Consume mucha batería?**
R: No, el consumo es mínimo. Es un servicio muy ligero.

**P: ¿Puedo crear mis propios cursores?**
R: Sí, si sabes editar archivos XML. Los cursores están en la carpeta `drawable`.

**P: ¿Es gratis?**
R: Completamente gratis y de código abierto.

**P: ¿Funciona con mouse Bluetooth?**
R: Sí, si conectas un mouse Bluetooth, también verás el cursor personalizado.

**P: ¿Puedo cambiar los colores de los cursores?**
R: Sí, editando los archivos XML en la carpeta del proyecto.

---

## 🎉 ¡LISTO!

Ya tienes cursores personalizados en tu HyperDroid. 

Si tienes problemas, revisa la sección de **Solución de Problemas** arriba.

**¡Disfruta tu experiencia PC en Android! 🖱️✨**
