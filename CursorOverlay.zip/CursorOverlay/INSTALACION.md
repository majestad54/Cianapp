# 🚀 GUÍA RÁPIDA DE INSTALACIÓN

## Para usuarios (Sin compilar, APK pre-compilado)

### ⚠️ IMPORTANTE
Si tienes el APK ya compilado, salta directamente al paso 3.

Si necesitas compilar el APK tú mismo, sigue desde el paso 1.

---

## OPCIÓN A: Ya tengo el APK

### 3. Instalar en tu Android

1. **Transfiere el APK a tu teléfono:**
   - Por cable USB: Copia `app-debug.apk` a la carpeta de Descargas
   - Por WiFi: Envíalo por WhatsApp, Telegram, Drive, etc.

2. **Instala el APK:**
   - Abre el archivo APK desde tu teléfono
   - Si aparece "Instalar desde fuentes desconocidas", actívalo
   - Toca "Instalar"
   - Espera a que termine
   - Toca "Abrir"

3. **Configuración inicial:**
   - En la app, toca el botón verde "▶ ACTIVAR CURSOR"
   - Te pedirá un permiso especial
   - Activa "Permitir mostrar sobre otras aplicaciones"
   - Regresa a la app
   - Toca nuevamente "▶ ACTIVAR CURSOR"

4. **¡Listo! Usa la app:**
   - Abre HyperDroid
   - Verás un panel flotante en la esquina
   - Toca los botones para cambiar el cursor:
     * ↖️ Flecha normal
     * 👆 Mano
     * ⏳ Cargando
     * ➕ Cruz
     * ↔️ Redimensionar
     * ✕ Cerrar

5. **Usa con mouse (Recomendado):**
   - Conecta un mouse Bluetooth a tu Android
   - El cursor seguirá automáticamente el puntero
   - ¡Mucho mejor experiencia!

---

## OPCIÓN B: Necesito compilar el APK

### 1. Requisitos previos

- **Windows/Mac/Linux** con al menos 8GB RAM
- **Android Studio** instalado
- **Java JDK 17** o superior
- **Espacio en disco:** 5GB libres

### 2. Compilar el APK

#### Método 1: Con Android Studio (Más fácil)

1. Abre Android Studio
2. File → Open
3. Selecciona la carpeta `CursorOverlay`
4. Espera que Gradle sincronice (puede tardar 5-10 minutos la primera vez)
5. Build → Build Bundle(s) / APK(s) → Build APK(s)
6. Espera a que compile
7. Click en "locate" cuando termine
8. Tu APK estará en: `app/build/outputs/apk/debug/app-debug.apk`

#### Método 2: Desde terminal (Más rápido)

**Linux/Mac:**
```bash
cd CursorOverlay
./build-apk.sh
```

**Windows:**
```cmd
cd CursorOverlay
build-apk.bat
```

El APK estará en: `app/build/outputs/apk/debug/app-debug.apk`

### 3. Continúa con "OPCIÓN A" paso 3

---

## 🎯 Consejos de uso

### Para mejor experiencia:

1. **Conecta un mouse Bluetooth:**
   - Configuración → Bluetooth → Emparejar
   - El cursor funcionará como en PC

2. **Ajusta el panel flotante:**
   - Mantén presionado el panel
   - Arrástralo a donde quieras
   - Se quedará ahí hasta que lo cierres

3. **Ahorra batería:**
   - Cierra el cursor cuando no uses HyperDroid
   - Toca el botón ✕ en el panel
   - O abre la app y toca "⏹ DETENER CURSOR"

### Atajos útiles:

- **Cambiar cursor rápido:** Toca el emoji en el panel
- **Mover panel:** Mantén presionado y arrastra
- **Ver notificación:** Desliza barra de notificaciones
- **Acceso rápido:** Desde la notificación

---

## ❓ Solución de problemas comunes

### El cursor no aparece
**Solución:** Ve a Configuración → Apps → HyperDroid Cursor → Permisos → Activa "Mostrar sobre otras apps"

### El panel está en una posición molesta
**Solución:** Mantén presionado el panel y arrástralo a otro lugar

### No puedo tocar el botón ✕ para cerrar
**Solución:** Arrastra primero el panel a un lugar más accesible

### La app consume mucha batería
**Solución:** Es normal, corre en primer plano. Ciérrala cuando no la uses.

### No veo el cursor con mi dedo
**Solución:** Esta app funciona mejor con mouse Bluetooth. El touch es experimental.

### La app se cerró sola
**Solución:** Android puede cerrar apps en segundo plano. Reactívala desde la app.

---

## 📞 ¿Necesitas ayuda?

Si algo no funciona:
1. Lee el README.md completo
2. Verifica que cumples los requisitos
3. Revisa que otorgaste todos los permisos
4. Intenta reiniciar tu teléfono

---

**¡Disfruta de tu experiencia mejorada con HyperDroid!** 🎉
