package com.cursoroverlay.hyperdroid;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.core.app.NotificationCompat;

public class CursorOverlayService extends Service {

    private WindowManager windowManager;
    private ImageView cursorView;
    private WindowManager.LayoutParams params;
    
    private String currentCursorType = "arrow";
    private int currentCursorSize = 40; // dp
    
    private static final String CHANNEL_ID = "CursorOverlayChannel";
    private static final int NOTIFICATION_ID = 1;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());
        
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createCursorView();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case "START_CURSOR":
                    showCursor();
                    break;
                case "CHANGE_CURSOR_TYPE":
                    currentCursorType = intent.getStringExtra("cursorType");
                    updateCursorImage();
                    break;
                case "CHANGE_CURSOR_SIZE":
                    currentCursorSize = intent.getIntExtra("cursorSize", 40);
                    updateCursorSize();
                    break;
            }
        }
        return START_STICKY;
    }

    private void createCursorView() {
        cursorView = new ImageView(this);
        cursorView.setImageResource(getCursorResource(currentCursorType));
        
        int layoutType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutType = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        // Interceptar eventos de toque en toda la pantalla
        View touchInterceptor = new View(this);
        WindowManager.LayoutParams interceptorParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
        );

        touchInterceptor.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                params.x = (int) event.getRawX() - (currentCursorSize / 2);
                params.y = (int) event.getRawY() - (currentCursorSize / 2);
                
                if (cursorView.getParent() != null) {
                    windowManager.updateViewLayout(cursorView, params);
                }
                
                // Cambiar cursor según el tipo de evento
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        cursorView.setAlpha(1.0f);
                        break;
                    case MotionEvent.ACTION_UP:
                        cursorView.setAlpha(0.8f);
                        break;
                }
                
                return false; // No consumir el evento
            }
        });

        try {
            windowManager.addView(touchInterceptor, interceptorParams);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showCursor() {
        try {
            if (cursorView.getParent() == null) {
                windowManager.addView(cursorView, params);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateCursorImage() {
        if (cursorView != null) {
            cursorView.setImageResource(getCursorResource(currentCursorType));
        }
    }

    private void updateCursorSize() {
        if (cursorView != null && params != null) {
            int sizePx = dpToPx(currentCursorSize);
            params.width = sizePx;
            params.height = sizePx;
            
            if (cursorView.getParent() != null) {
                windowManager.updateViewLayout(cursorView, params);
            }
        }
    }

    private int getCursorResource(String type) {
        switch (type) {
            case "hand":
                return R.drawable.cursor_hand;
            case "loading":
                return R.drawable.cursor_loading;
            case "crosshair":
                return R.drawable.cursor_crosshair;
            case "resize":
                return R.drawable.cursor_resize;
            default:
                return R.drawable.cursor_arrow;
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Cursor Overlay",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Cursor personalizado activo");
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Cursor Personalizado")
                .setContentText("El cursor está activo en HyperDroid")
                .setSmallIcon(R.drawable.ic_cursor_notification)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cursorView != null && cursorView.getParent() != null) {
            windowManager.removeView(cursorView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
