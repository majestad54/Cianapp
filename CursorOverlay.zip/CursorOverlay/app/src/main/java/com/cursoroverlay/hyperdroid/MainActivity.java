package com.cursoroverlay.hyperdroid;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Switch switchService;
    private RadioGroup cursorTypeGroup;
    private SeekBar cursorSizeSeekBar;
    private TextView sizeValueText;
    private Button btnRequestPermission;
    
    private static final int OVERLAY_PERMISSION_REQUEST_CODE = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        checkOverlayPermission();
        setupListeners();
    }

    private void initViews() {
        switchService = findViewById(R.id.switchService);
        cursorTypeGroup = findViewById(R.id.cursorTypeGroup);
        cursorSizeSeekBar = findViewById(R.id.cursorSizeSeekBar);
        sizeValueText = findViewById(R.id.sizeValueText);
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                btnRequestPermission.setEnabled(true);
                switchService.setEnabled(false);
                Toast.makeText(this, "Se requiere permiso de superposición", Toast.LENGTH_LONG).show();
            } else {
                btnRequestPermission.setEnabled(false);
                switchService.setEnabled(true);
            }
        }
    }

    private void setupListeners() {
        // Switch para activar/desactivar el servicio
        switchService.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                startCursorService();
            } else {
                stopCursorService();
            }
        });

        // RadioGroup para cambiar tipo de cursor
        cursorTypeGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String cursorType = getCursorTypeFromId(checkedId);
            Intent intent = new Intent(this, CursorOverlayService.class);
            intent.setAction("CHANGE_CURSOR_TYPE");
            intent.putExtra("cursorType", cursorType);
            startService(intent);
        });

        // SeekBar para cambiar tamaño del cursor
        cursorSizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int size = progress + 20; // Mínimo 20dp
                sizeValueText.setText(size + " dp");
                
                Intent intent = new Intent(MainActivity.this, CursorOverlayService.class);
                intent.setAction("CHANGE_CURSOR_SIZE");
                intent.putExtra("cursorSize", size);
                startService(intent);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Botón para solicitar permiso
        btnRequestPermission.setOnClickListener(v -> requestOverlayPermission());
    }

    private String getCursorTypeFromId(int checkedId) {
        if (checkedId == R.id.radioArrow) return "arrow";
        if (checkedId == R.id.radioHand) return "hand";
        if (checkedId == R.id.radioLoading) return "loading";
        if (checkedId == R.id.radioCrosshair) return "crosshair";
        if (checkedId == R.id.radioResize) return "resize";
        return "arrow";
    }

    private void startCursorService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Se requiere permiso de superposición", Toast.LENGTH_SHORT).show();
            switchService.setChecked(false);
            return;
        }

        Intent intent = new Intent(this, CursorOverlayService.class);
        intent.setAction("START_CURSOR");
        startService(intent);
        Toast.makeText(this, "Cursor activado ✓", Toast.LENGTH_SHORT).show();
    }

    private void stopCursorService() {
        Intent intent = new Intent(this, CursorOverlayService.class);
        stopService(intent);
        Toast.makeText(this, "Cursor desactivado", Toast.LENGTH_SHORT).show();
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST_CODE) {
            checkOverlayPermission();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkOverlayPermission();
    }
}
